﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
using Dominio;
using System.Diagnostics.Eventing.Reader;

namespace Negocio
{
  public  class CarritoNegocio
    {

        public void Agregar(Articulo articulos)
        {
            
   
        }
        
    }
}
