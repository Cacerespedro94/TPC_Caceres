﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
  
   public class Cliente:Persona
    {
        //public Cliente()
        //{
        //    User = new Usuario();
        //    direccion = new Direccion();
        //    contacto = new Contacto();
        //    Estado = false;
        //    User.tipo = 2;
        //}
        //public Direccion direccion  { get; set; }
        //public Contacto contacto { get; set; }
        //public bool Estado { get; set; }
    }
}
