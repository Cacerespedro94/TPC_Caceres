//------------------------------------------------------------------------------
// <generado autom�ticamente>
//     Este c�digo fue generado por una herramienta.
//
//     Los cambios en este archivo podr�an causar un comportamiento incorrecto y se perder�n si
//     se vuelve a generar el c�digo. 
// </generado autom�ticamente>
//------------------------------------------------------------------------------

namespace TPC_Caceres
{


    public partial class Site_Mobile
    {

        /// <summary>
        /// Control HeadContent.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ContentPlaceHolder HeadContent;

        /// <summary>
        /// Control form1.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// Control FeaturedContent.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ContentPlaceHolder FeaturedContent;

        /// <summary>
        /// Control MainContent.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ContentPlaceHolder MainContent;
    }
}
